CREATE TABLE test_caractere (
	char_col char(6)
, varchar_col varchar(6)
, text_col text
);

-- Insérer chaine inférieure à 6 caractères
INSERT INTO test_caractere (char_col) 
VALUES ('abc') 
RETURNING *;

-- Insérer chaine supérieure à 6 caractères
INSERT INTO test_caractere (char_col) 
VALUES ('abcdefg')
RETURNING *;;

-- Insérer chaine inférieure à 6 caractères
INSERT INTO test_caractere (varchar_col) 
VALUES ('abc') 
RETURNING *;

-- Insérer chaine supérieure à 6 caractères
INSERT INTO test_caractere (varchar_col) 
VALUES ('abcdefg');

-- Insérer une trèèèèèès longue chaîne
INSERT INTO test_caractere (text_col) 
VALUES ('abcdefgsgdfgdfgfd sdgkldsfjgslkfdjgsdlfkj fdslmhgjsklhj sqùlkdsfjhsdfùlkj qdsùlmkjfsgdlh sùfkj ùdlfmkjh sfgùlkhjsf gùlhkjfgh ùsflgjkh sfdùlkhjsfg hùlkjh gsfùljhk sfùgkj') 
RETURNING *;


-- Pour s'assurer du format de la chaine de caractère en MAJUSCULE
SELECT UPPER('arTHur')

-- Pour s'assurer du format de la chaine de caractère en miniscule
SELECT LOWER('ArTHur')

-- Pour s'assurer que le format est en 'Casse Capitale'
SELECT INITCAP('ArTHur dElABorDe')




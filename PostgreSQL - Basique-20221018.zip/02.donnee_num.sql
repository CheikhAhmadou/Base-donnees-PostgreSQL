CREATE TABLE test_numerique (
  petit_entier SMALLINT
, moyen_entier INTEGER
, grand_entier BIGINT
, reel REAL
, precision_double DOUBLE PRECISION
, numerique_contraint NUMERIC(8,2)
, numerique_non_contraint NUMERIC
);

-- Insertion d'un petit entier valide
INSERT INTO test_numerique (petit_entier) 
VALUES (45)
RETURNING *;

-- Insertion d'un petit entier invalide
INSERT INTO test_numerique (petit_entier) 
VALUES (32768)
RETURNING *;

-- Insertion d'un entier invalide
INSERT INTO test_numerique (moyen_entier) 
VALUES (-2147483649)
RETURNING *;

-- Insertion d'un grand entier invalide
INSERT INTO test_numerique (moyen_entier) 
VALUES (9223372036854775808)
RETURNING *;

-- Insertion d'un reel valide
INSERT INTO test_numerique (reel) 
VALUES (1481.87)
RETURNING *;

-- Insertion d'un reel avec une perte de précision avant la décimale
INSERT INTO test_numerique (reel) 
VALUES (123456789101112.01)
RETURNING *;

-- Insertion d'un reel avec une perte de précision après la décimale
INSERT INTO test_numerique (reel) 
VALUES (1.1234567891011121314151617181920212223242512345678910111213141516171819202122232425)
RETURNING *;

-- Insertion d'un reel invalide
INSERT INTO test_numerique (reel) 
VALUES (12345678910111213141516171819202122232425.01020304)
RETURNING *;

-- Pas de prolème similaire avec DOUBLE PRECISION (mais perte de précision à partir d'un certain nombre avant la virgule)
INSERT INTO test_numerique (precision_double) 
VALUES (123456789101112131415161718192021222324251586165156156123456789101112131415161878745847545465165816848616461546581651685463168436516384163516841352163546358186163518524871819202122232425)
RETURNING *;

-- Insérer dans la colonne numérique contrainte
INSERT INTO test_numerique (numerique_contraint) 
VALUES (123456.78)
RETURNING *;

-- Insérer dans la colonne numérique contrainte un nombre trop grand
INSERT INTO test_numerique (numerique_contraint) 
VALUES (1234567.78)
RETURNING *;

-- Insérer dans la colonne numérique contrainte un nombre avec une précision trop grande aboutit a son arrondissement
INSERT INTO test_numerique (numerique_contraint) 
VALUES (123456.78910)
RETURNING *;

-- Insérer dans la colonne numérique non contrainte
INSERT INTO test_numerique (numerique_non_contraint) 
VALUES (123456789101112131415161718192021222324252627282930313233435363738394041424344454647484950.123456789101112131415161718192021222324252627282930313233435363738394041424344454647484950)
RETURNING *;

